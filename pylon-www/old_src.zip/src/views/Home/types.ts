export interface OverviewData {
  circSupply?: string,
  curPrice?: number,
  nextRebase?: number,
  targetPrice?: number,
  totalSupply?: string
}