export { default } from './Modal'
export type { ModalProps } from './Modal'